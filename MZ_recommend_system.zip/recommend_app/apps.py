from django.apps import AppConfig


class RecommendAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'recommend_app'
